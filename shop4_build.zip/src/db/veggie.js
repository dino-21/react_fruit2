let veggie = [
    {
      id: 1,
      title: "당근",
      imgUrl: "img/veggie/veggie1.jpg",
      content: "국내산 햇당근 1kg",
      price: 11900,
    },
    {
      id: 2,
      title: "옥수수",
      imgUrl: "img/veggie/veggie2.jpg",
      content: "쫀득쫀득 찰옥수수 250g",
      price: 29000,
    },
    {
      id: 3,
      title: "감자",
      imgUrl: "img/veggie/veggie3.jpg",
      content: "강원도 두백산 수미 감자 33kg",
      price: 30000,
    },
  ];
  
  export default veggie;
  